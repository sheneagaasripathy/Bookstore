package com.biruntha.security.basicauth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootSecurityBasicauthMongodbApplicationTests {

	@Test
	void contextLoads() {
	}

}
