package com.biruntha.security.basicauth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootSecurityBasicauthMongodbApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootSecurityBasicauthMongodbApplication.class, args);
	}

}
