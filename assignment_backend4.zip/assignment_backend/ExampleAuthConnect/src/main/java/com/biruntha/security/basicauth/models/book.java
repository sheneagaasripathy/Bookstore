package com.biruntha.security.basicauth.models;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "book")
public class book {
	
	@Id
	private String id;
	private String title;
	private String author;
	private String bookUrl;
	private long isbn;
	private int price;
	private String language;
	private String genre;
	
	public book(String id, String title, String author, String bookUrl, long isbn, int price, String language,
			String genre) {
		super();
		this.id = id;
		this.title = title;
		this.author = author;
		this.bookUrl = bookUrl;
		this.isbn = isbn;
		this.price = price;
		this.language = language;
		this.genre = genre;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getBookUrl() {
		return bookUrl;
	}

	public void setBookUrl(String bookUrl) {
		this.bookUrl = bookUrl;
	}

	public long getIsbn() {
		return isbn;
	}

	public void setIsbn(long isbn) {
		this.isbn = isbn;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	@Override
	public String toString() {
		return "book [id=" + id + ", title=" + title + ", author=" + author + ", bookUrl=" + bookUrl + ", isbn=" + isbn
				+ ", price=" + price + ", language=" + language + ", genre=" + genre + "]";
	}
	
	
	
	
	

}
